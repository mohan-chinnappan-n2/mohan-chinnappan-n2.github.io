bin/zookeeper-server-start.sh config/zookeeper.properties
