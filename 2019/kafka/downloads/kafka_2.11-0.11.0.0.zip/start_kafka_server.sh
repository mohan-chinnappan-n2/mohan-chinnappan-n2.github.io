bin/kafka-server-start.sh config/server.properties
