bin/kafka-topics.sh --list --zookeeper localhost:2181
