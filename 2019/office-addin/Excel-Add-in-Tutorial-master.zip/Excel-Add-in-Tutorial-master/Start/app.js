/*
 * Copyright (c) Microsoft Corporation. All rights reserved. Licensed under the MIT license.
 * See LICENSE in the project root for license information.
 */

'use strict';

(function () {

	Office.onReady()
		    .then(function() {
		        $(document).ready(function () {

            // TODO1: Determine if the user's version of Office supports all the
            //        Office.js APIs that are used in the tutorial.

            // TODO2: Assign event handlers and other initialization logic.

        });
    });

    // TODO3: Add handlers and business logic functions here.

})();