const fetch = require('node-fetch');

exports.handler = async (event) => {

    await sendPOST();
    return { statusCode: 200, body: "Ok"};
};

async function sendGET() {
    const url = "https://mohansun-fsc-21.my.salesforce.com/services/data";


   const params = {
        method: "GET",
        mode: "cors",
        headers: {"Content-Type":"application/json" },
    };
    await fetch(url, params);
}

async function sendPOST() {
    const sobj = 'LCTest__e';
    const url = `https://mohansun-fsc-21.my.salesforce.com/services/data/v46.0/sobjects/${sobj}`;

    const at = `00D3h000000DC8N!ARcAQAEoNV.jGPdWoODD.GeAp.tzVqKQt_Cci1lrl91CL__WosVlAfOLCKx9tjIuI.I7JWablqx9pu8q209YiG18XIyz2e2A`;
    const postbody = { "msg__c": "Create", "fname__c": "Johnny", "lname__c": "Sailer", "cname__c": "Jonny Sailer Sons" } ;

    const params = {
        method: "POST",
        mode: "cors",
        headers: {"Content-Type":"application/json", "Authorization": `Bearer ${at}` },
        body: JSON.stringify(postbody)
    };
    await fetch(url, params);
}




