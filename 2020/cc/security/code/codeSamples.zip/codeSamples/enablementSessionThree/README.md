# Enablement Session #3 demo
> Building experiences for your LWC Community
## Overview

- How to leverage 3rd party libraries
- How to access data and metadata using UI APIs and Apex
- How to present data using custom and base Lightning components
- How to implement custom search and navigation