
import { LightningElement } from 'lwc';

/**
 * @slot sidebar
 */
export default class CustomLayout extends LightningElement {}