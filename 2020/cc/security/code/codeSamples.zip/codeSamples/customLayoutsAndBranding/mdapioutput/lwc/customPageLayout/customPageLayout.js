import { LightningElement } from 'lwc';

/**
 * @slot region1
 * @slot region2
 */
export default class CustomPageLayout extends LightningElement {}