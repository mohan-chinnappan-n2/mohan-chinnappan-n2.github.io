import { createMessageChannel } from 'lightning/messageService';

const MESSAGE_CHANNEL =  createMessageChannel();
export { MESSAGE_CHANNEL };